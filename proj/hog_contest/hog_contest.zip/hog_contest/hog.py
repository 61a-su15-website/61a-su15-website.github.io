"""This is a minimal contest submission file. You may also submit the full
hog.py from Project 1 as your contest entry."""

def final_strategy(score, opponent_score):
    return 5

