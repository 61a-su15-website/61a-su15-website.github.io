################
# Lab 7: Trees #
################

def lab7_q1():
    """
    >>> isinstance(lab7_q1(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab7_q2():
    """
    >>> isinstance(lab7_q2(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab7_q3():
    """
    >>> isinstance(lab7_q3(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab7_q4():
    """
    >>> isinstance(lab7_q4(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

######################################
# Lab 8: Object-Oriented Programming #
######################################

def lab8_q2():
    """
    >>> isinstance(lab8_q2(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab8_q3():
    """
    >>> isinstance(lab8_q3(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab8_q4():
    """
    >>> isinstance(lab8_q4(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab8_q5():
    """
    >>> isinstance(lab8_q5(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

###############################
# Lab 9: Mutable Linked Lists #
###############################

def lab9_q2():
    """
    >>> isinstance(lab9_q2(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab9_q3():
    """
    >>> isinstance(lab9_q3(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab9_q4():
    """
    >>> isinstance(lab9_q4(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab9_q5():
    """
    >>> isinstance(lab9_q5(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

######################
# Lab 10: Interfaces #
######################

def lab10_q1():
    """
    >>> isinstance(lab10_q2(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab10_q2():
    """
    >>> isinstance(lab10_q3(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab10_q3():
    """
    >>> isinstance(lab10_q4(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab10_q4():
    """
    >>> isinstance(lab10_q5(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab10_q5():
    """
    >>> isinstance(lab10_q5(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """

def lab10_q6():
    """
    >>> isinstance(lab10_q5(), str)
    True
    """
    return """
    YOUR EXPLANATION HERE
    """
