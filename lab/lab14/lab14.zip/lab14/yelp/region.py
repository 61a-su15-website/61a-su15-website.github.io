REGION = 'us-west-2'
